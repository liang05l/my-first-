#!/system/bin/sh

LOGFILE="/data/adb/modules/disable_ipv6_module/disable_ipv6_log.txt"
MAX_LOG_SIZE=1000000  # 限制日志文件大小为 1 MB
ENABLE_LOG=true      # 日志记录开关，默认为开启

# 禁用IPv6
disable_ipv6() {
    if check_logging; then
        echo "$(date) - Disabling IPv6" >> "$LOGFILE"
    fi
    echo 0 | tee /proc/sys/net/ipv6/conf/wlan0/accept_ra
    echo 1 | tee /proc/sys/net/ipv6/conf/all/disable_ipv6
}

# 检查日志开关
check_logging() {
    if [ "$ENABLE_LOG" = true ]; then
        return 0  # 日志记录已启用
    else
        return 1  # 日志记录未启用
    fi
}

# 监听WiFi连接变化
monitor_wifi() {
    sleep 30  # 开机延时 30 秒
    rm -rf "/data/adb/modules/disable_ipv6_module/ipv6_disabled.flag"
    
    if [ ! -f /storage/emulated/0/Android/disable_ipv6_config ]; then
        mkdir -p /storage/emulated/0/Android
        cat > /storage/emulated/0/Android/disable_ipv6_config <<EOF
SSID=此处填入WiFi名不能有空格，修改后重启手机
EOF
    fi

    CONFIG_FILE="/storage/emulated/0/Android/disable_ipv6_config"
    if [ -f "$CONFIG_FILE" ]; then
        SSID=$(grep SSID "$CONFIG_FILE" | cut -d'=' -f2)
        if check_logging; then
            echo "$(date) - Monitoring WiFi for SSID: $SSID" >> "$LOGFILE"
        fi
        
        while true; do
            CURRENT_SSID=$(dumpsys netstats | grep 'iface=wlan0' | grep -o 'wifiNetworkKey="[^\"]*"' | cut -d'"' -f2 | awk 'NR==1')
            if check_logging; then
                echo "$(date) - Current SSID: $CURRENT_SSID" >> "$LOGFILE"
            fi
            
            if [ "$CURRENT_SSID" = "$SSID" ]; then
                # 检查是否已经执行过禁用IPv6操作
                if [ ! -f "/data/adb/modules/disable_ipv6_module/ipv6_disabled.flag" ]; then
                    disable_ipv6
                    touch "/data/adb/modules/disable_ipv6_module/ipv6_disabled.flag"
                fi
            else
                # 如果不再指定的SSID范围内，删除禁用标志文件
                rm -rf "/data/adb/modules/disable_ipv6_module/ipv6_disabled.flag"
            fi
            
            # 如果启用了日志记录，检查日志文件大小并备份
            if check_logging; then
                LOG_SIZE=$(stat -c %s "$LOGFILE" 2>/dev/null || echo 0)
                if [ $LOG_SIZE -gt $MAX_LOG_SIZE ]; then
                    mv "$LOGFILE" "$LOGFILE.old"
                    echo "$(date) - Log file exceeded max size. Rotated." > "$LOGFILE"
                fi
            fi
            
            sleep 10
        done
    else
        if check_logging; then
            echo "$(date) - Config file not found: $CONFIG_FILE" >> "$LOGFILE"
        fi
    fi
}

monitor_wifi &   # 启动WiFi监控任务