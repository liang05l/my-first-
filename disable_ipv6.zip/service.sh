#!/system/bin/sh
MODDIR=${0%/*}

# 这个脚本将在每次启动时执行
sh $MODDIR/common/post-fs-data.sh &
